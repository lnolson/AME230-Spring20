//
//  ViewController.swift
//  Circle Demo
//
//

import Cocoa
import Tin


class ViewController: TController {

    //
    // viewWillAppear will be called once, just before the view is placed on screen.
    //
    override func viewWillAppear() {
        view.window?.title = "Car Demo"
        makeView(width: 1000.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var car1 = Car()
    var car2 = Car()
    
    
    override func setup() {
        car2.y = 300.0
        car2.size = 128.0
        car2.velocity = 2.0
        car2.green = 1.0
        car2.red = 0.1
    }
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        background(gray: 0.5)
        
        
        car1.move()
        car1.draw()
        
        car2.move()
        car2.draw()
        
    }
    
    
    

    
}


class Car {
    var x = 100.0
    var y = 100.0
    var size = 64.0
    var velocity = 1.0
    var red = 1.0
    var green = 0.1
    var blue = 0.1
    
    func draw() {
        
        strokeColor(gray: 0.0)
        fillColor(red: red, green: green, blue: blue, alpha: 1.0)
        rect(x: x, y: y, width: size, height: size/2.0)
        
        let offset = size / 4.0
        let cx = x + size / 2.0
        let cy = y + size / 4.0
        let tw = offset
        let th = offset / 2.0
        fillColor(gray: 0.0)
        rect(x: cx - offset - tw/2.0, y: cy - offset - th, width: tw, height: th)
        rect(x: cx + offset - tw/2.0, y: cy - offset - th, width: tw, height: th)
        rect(x: cx - offset - tw/2.0, y: cy + offset, width: tw, height: th)
        rect(x: cx + offset - tw/2.0, y: cy + offset, width: tw, height: th)
    }
    
    func move() {
        x = x + velocity
        if x > tin.width {
            x = -size
        }
    }
    
}


