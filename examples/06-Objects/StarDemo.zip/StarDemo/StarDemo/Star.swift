//
//  Star.swift
//  StarDemo
//
//

import Foundation
import Tin


class Star {
    // properties
    var x: Double
    var y: Double
    var radius: Double
    var angle: Double
    var red: Double
    var green: Double
    var blue: Double
    var numberOfPoints: Int
    var armDepth: Double
    var speed: Double
    
    
    // MARK: - Initializer
    
    init(x: Double, y: Double, radius: Double) {
        self.x = x
        self.y = y
        self.radius = radius
        angle = 0.0
        red = random(min: 0, max: 1)
        green = random(min: 0, max: 1)
        blue = random(min: 0, max: 1)
        numberOfPoints = 5
        armDepth = 0.5
        speed = random(min: 0.005, max: 0.025)
    }
    
    // MARK: - Instance methods
    
    func render() {
        lineWidth(1.0)
        fillColor(red: red, green: green, blue: blue, alpha: 1.0)
        pathBegin()
        
        let offset = (.pi * 2.0) / Double(numberOfPoints * 2)
        
        var a = angle
        for _ in 0 ..< numberOfPoints {
            let x1 = radius * cos( a ) + x
            let y1 = radius * sin( a ) + y
            pathVertex(x: x1, y: y1)
            
            a += offset
            
            let x2 = radius * armDepth * cos( a ) + x
            let y2 = radius * armDepth * sin( a ) + y
            pathVertex(x: x2, y: y2)
            
            a += offset
        }
        pathClose()
    }
    
    
    func spin() {
        angle += speed
    }
}
