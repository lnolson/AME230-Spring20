//
//  ViewController.swift
//  Star Demo
//
//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    //
    // viewWillAppear will be called once, just before the view is placed on screen.
    //
    override func viewWillAppear() {
        view.window?.title = "Star"
        makeView(width: 1000.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    // mouseUp is called whenever the user releases the mouse button.
    override func mouseUp(with event: NSEvent) {
    }

}


class Scene: TScene {
    var stars: [Star] = []
    
    // The setup function is called once, before any drawing.
    override func setup() {
        for _ in 1...100 {
            let x = random(min: 0, max: tin.width)
            let y = random(min: 0, max: tin.height)
            let radius = random(min: 20.0, max: 80.0)
            let star = Star(x: x, y: y, radius: radius)
            stars.append(star)
        }
    }
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        background(gray: 0.5)
        
        for star in stars {
            star.spin()
            star.render()
        }
    }
    
}





