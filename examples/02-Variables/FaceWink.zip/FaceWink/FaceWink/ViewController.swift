//
//  ViewController.swift
//  Drawing
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Drawing"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    

    override func update() {
        background(gray: 0.5)
        
        
        let faceCenterX = 400.0
        let faceCenterY = 300.0
        let faceWidth = 200.0
        fillColor(red: 1, green: 0.8, blue: 0, alpha: 1)
        ellipse(centerX: faceCenterX, centerY: faceCenterY, width: faceWidth, height: faceWidth)
        
        let ratio = tin.mouseY / tin.height
        
        let eyeLeft = faceCenterX - (faceWidth * 0.2)
        let eyeRight = faceCenterX + (faceWidth * 0.2)
        let eyeLevel = faceCenterY + (faceWidth * 0.125)
        let eyeWidth = faceWidth * 0.1
        let eyeHeight = faceWidth * 0.15
        strokeDisable()
        fillColor(red: 0.4, green: 0.2, blue: 0, alpha: 1)
        ellipse(centerX: eyeLeft, centerY: eyeLevel, width: eyeWidth, height: eyeHeight)
        ellipse(centerX: eyeRight, centerY: eyeLevel, width: eyeWidth + ((1.0 - ratio) * eyeWidth), height: eyeHeight * ratio)
        
        let mouthX = faceCenterX - (faceWidth * 0.2)
        let mouthY = faceCenterY - (faceWidth * 0.25)
        let mouthWidth = faceWidth * 0.4
        let mouthHeight = faceWidth * 0.1
        rect(x: mouthX, y: mouthY, width: mouthWidth, height: mouthHeight)

        
        //view?.stopUpdates()
    }
    
}

