//
//  ViewController.swift
//  Drawing
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Iso Cubes"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        // background erases the view and sets the entire view to one flat
        // color. If you want a different background color, change it here.
        background(gray: 0.5)
        
        // *************************************************
        // Insert your drawing code here, below this comment
        
        lineWidth(1)
        
        // Cube 1
        fillColor(gray: 0.4)
        pathBegin()
        pathVertex(x: 101, y: 125)
        pathVertex(x: 150, y: 101)
        pathVertex(x: 150, y: 150)
        pathVertex(x: 101, y: 175)
        pathClose()
        
        fillColor(gray: 0.7)
        pathBegin()
        pathVertex(x: 150, y: 101)
        pathVertex(x: 200, y: 125)
        pathVertex(x: 200, y: 175)
        pathVertex(x: 150, y: 150)
        pathClose()
        
        fillColor(gray: 0.3)
        pathBegin()
        pathVertex(x: 101, y: 175)
        pathVertex(x: 150, y: 150)
        pathVertex(x: 200, y: 175)
        pathVertex(x: 150, y: 200)
        pathClose()
        
        // Cube 2
        fillColor(gray: 0.4)
        pathBegin()
        pathVertex(x: 201, y: 125)
        pathVertex(x: 250, y: 101)
        pathVertex(x: 250, y: 150)
        pathVertex(x: 201, y: 175)
        pathClose()
        
        fillColor(gray: 0.7)
        pathBegin()
        pathVertex(x: 250, y: 101)
        pathVertex(x: 300, y: 125)
        pathVertex(x: 300, y: 175)
        pathVertex(x: 250, y: 150)
        pathClose()
        
        fillColor(gray: 0.3)
        pathBegin()
        pathVertex(x: 201, y: 175)
        pathVertex(x: 250, y: 150)
        pathVertex(x: 300, y: 175)
        pathVertex(x: 250, y: 200)
        pathClose()
        
        // Cube 3
        fillColor(gray: 0.4)
        pathBegin()
        pathVertex(x: 301, y: 125)
        pathVertex(x: 350, y: 101)
        pathVertex(x: 350, y: 150)
        pathVertex(x: 301, y: 175)
        pathClose()
        
        fillColor(gray: 0.7)
        pathBegin()
        pathVertex(x: 350, y: 101)
        pathVertex(x: 400, y: 125)
        pathVertex(x: 400, y: 175)
        pathVertex(x: 350, y: 150)
        pathClose()
        
        fillColor(gray: 0.3)
        pathBegin()
        pathVertex(x: 301, y: 175)
        pathVertex(x: 350, y: 150)
        pathVertex(x: 400, y: 175)
        pathVertex(x: 350, y: 200)
        pathClose()
        
        
        // Cube 4
        fillColor(gray: 0.4)
        pathBegin()
        pathVertex(x: 151, y: 200)
        pathVertex(x: 200, y: 176)
        pathVertex(x: 200, y: 225)
        pathVertex(x: 151, y: 250)
        pathClose()
        
        fillColor(gray: 0.7)
        pathBegin()
        pathVertex(x: 200, y: 176)
        pathVertex(x: 250, y: 200)
        pathVertex(x: 250, y: 250)
        pathVertex(x: 200, y: 225)
        pathClose()
        
        fillColor(gray: 0.3)
        pathBegin()
        pathVertex(x: 151, y: 250)
        pathVertex(x: 200, y: 225)
        pathVertex(x: 250, y: 250)
        pathVertex(x: 200, y: 275)
        pathClose()
        
        // Cube 5
        fillColor(gray: 0.4)
        pathBegin()
        pathVertex(x: 251, y: 200)
        pathVertex(x: 300, y: 176)
        pathVertex(x: 300, y: 225)
        pathVertex(x: 251, y: 250)
        pathClose()
        
        fillColor(gray: 0.7)
        pathBegin()
        pathVertex(x: 300, y: 176)
        pathVertex(x: 350, y: 200)
        pathVertex(x: 350, y: 250)
        pathVertex(x: 300, y: 225)
        pathClose()
        
        fillColor(gray: 0.3)
        pathBegin()
        pathVertex(x: 251, y: 250)
        pathVertex(x: 300, y: 225)
        pathVertex(x: 350, y: 250)
        pathVertex(x: 300, y: 275)
        pathClose()
        
        
        // Cube 6
        fillColor(gray: 0.4)
        pathBegin()
        pathVertex(x: 201, y: 275)
        pathVertex(x: 250, y: 251)
        pathVertex(x: 250, y: 300)
        pathVertex(x: 201, y: 325)
        pathClose()
        
        fillColor(gray: 0.7)
        pathBegin()
        pathVertex(x: 250, y: 251)
        pathVertex(x: 300, y: 275)
        pathVertex(x: 300, y: 325)
        pathVertex(x: 250, y: 300)
        pathClose()
        
        fillColor(gray: 0.3)
        pathBegin()
        pathVertex(x: 201, y: 325)
        pathVertex(x: 250, y: 300)
        pathVertex(x: 300, y: 325)
        pathVertex(x: 250, y: 350)
        pathClose()
        
        // Your drawing code should be above this comment.
        // *************************************************
        
        view?.stopUpdates()
    }
    
}

