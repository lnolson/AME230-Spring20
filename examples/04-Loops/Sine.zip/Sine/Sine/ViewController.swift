//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Sine"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    override func update() {
        background(gray: 0.5)
        
        var a = 0.0
        var x = 20.0
        
        strokeColor(gray: 1.0)
        fillDisable()
        pathBegin()
        
        while x + 20.0 <= tin.width {
            
            let y = (sin(a) * 50.0) + 300.0
            
            pathVertex(x: x, y: y)
            
            x += 5.0
            
            a += 0.2
            
        }
        
        pathEnd()
    }
    
}

