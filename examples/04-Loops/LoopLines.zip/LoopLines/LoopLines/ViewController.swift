//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {
    var scene = Scene()
    
    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    override func update() {
        background(gray: 0.5)
        
        let startY = 50.0
        let endY = 300.0
        
        var x = 20.0
        
        while x + 20.0 <= tin.width {
            
            line(x1: x, y1: startY, x2: x, y2: endY)
            
            x += 40.0
            
        } // end of while block
        
    } // end of update function
    
} // end of Scene object

