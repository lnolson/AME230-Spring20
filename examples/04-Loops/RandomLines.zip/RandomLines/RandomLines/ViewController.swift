//
//  ViewController.swift
//  Loop Demo
//
//

import Cocoa
import Tin


class ViewController: TController {
    var scene = Scene()

    //
    // viewWillAppear will be called once, just before the view is placed on screen.
    //
    override func viewWillAppear() {
        view.window?.title = "Loop"
        makeView(width: 800.0, height: 600.0)
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        background(gray: 0.5)
        
        var i = 0
        while i < 600 {
            
            let x1 = random(min: 10.0, max: tin.width - 10.0)
            let y1 = random(min: 10.0, max: tin.height - 10.0)
            
            let x2 = x1 + random(min: 10.0, max: 50.0)
            let y2 = y1 + random(min: 10.0, max: 50.0)
            
            line(x1: x1, y1: y1, x2: x2, y2: y2)
            
            i = i + 1
        }
        
        view?.stopUpdates()
    }
    
}


