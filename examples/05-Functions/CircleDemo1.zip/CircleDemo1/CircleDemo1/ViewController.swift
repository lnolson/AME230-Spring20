//
//  ViewController.swift
//  Circle Demo
//
//

import Cocoa
import Tin


class ViewController: TController {

    //
    // viewWillAppear will be called once, just before the view is placed on screen.
    //
    override func viewWillAppear() {
        view.window?.title = "Circle Demo"
        makeView(width: 1000.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        background(gray: 0.5)
        
        
        specialCircle(x: 500, y: 300, radius: 80)
        
        specialCircle(x: 700, y: 300, radius: 60)
        specialCircle(x: 300, y: 300, radius: 60)
        
    }
    
    
    func specialCircle(x: Double, y: Double, radius: Double) {
        strokeDisable()
        fillColor(red: 1, green: 0.3, blue: 0.2, alpha: 1)
        ellipse(centerX: x, centerY: y, width: radius * 2, height: radius * 2)
        
        fillColor(gray: 0.95)
        ellipse(centerX: x, centerY: y, width: radius * 2 * 0.67, height: radius * 2 * 0.67)
        
        fillColor(red: 1, green: 0.3, blue: 0.2, alpha: 1)
        ellipse(centerX: x, centerY: y, width: radius * 2 * 0.34, height: radius * 2 * 0.35)
    }
    
}


